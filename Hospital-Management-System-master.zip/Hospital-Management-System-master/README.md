# Hospital-Management-System
This fully complete demo project of the hospital management system allows authenticated users manage the statutory components of a health system.

This web based application is robust and was built on Code frameworks of JAVA open source programming language and MySQL database.

This system integrates and facilitates 5 types of user area of a hospital: Staff, Doctor,  Patient,  Nurse,  Appointment
